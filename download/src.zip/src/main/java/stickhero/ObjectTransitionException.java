package stickhero;

public class ObjectTransitionException extends Exception{
    public ObjectTransitionException(String message){
        super(message);
    }
}
